public class Main {

    /*
    The goal here is to make rob turn the whole arina light then turn it dark
    We are going to work with error's and creat part of RobotUtil
    for now focus on the initial goal of changing the arina

    REMEMBER CLASS.METHOD(); rob is the class and these are the methods rob can do
    rob.makeLight(); //will change the square to light
    rob.makeDark(); //will change the square to dark
     */

    public static void main(String[] args) {
        //partOne();
        //partTwo();
        //partThree();
        //partOneIf();
        //partTwoIf();
        //partThreeIf();
    }

    public static void partOne(){
        RobotUtil rob = new RobotUtil("combine.txt", Delay.MEDIUM);
        //code here//


        //DO NOT FORGET TO UNCOMMENT THE METHOD CALL IN MAIN SO THAT THIS WILL RUN
    }

    public static void partTwo(){
        RobotUtil rob = new RobotUtil("combine.txt", Delay.MEDIUM);
        //code here//


        //DO NOT FORGET TO UNCOMMENT THE METHOD CALL IN MAIN SO THAT THIS WILL RUN
    }

    public static void partThree(){
        //code here//


        //DO NOT FORGET TO UNCOMMENT THE METHOD CALL IN MAIN SO THAT THIS WILL RUN
    }

    public static void partOneIf(){
        //code here//


        //DO NOT FORGET TO UNCOMMENT THE METHOD CALL IN MAIN SO THAT THIS WILL RUN
    }

    public static void partTwoIf(){
        //code here//


        //DO NOT FORGET TO UNCOMMENT THE METHOD CALL IN MAIN SO THAT THIS WILL RUN
    }

    public static void partThreeIf(){
        //code here//


        //DO NOT FORGET TO UNCOMMENT THE METHOD CALL IN MAIN SO THAT THIS WILL RUN
    }


}