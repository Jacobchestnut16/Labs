public class Main {

    public static void main(String[] args) {
/*        System.out.println("Hello world!");
        RobotUtil rob = new RobotUtil("maze.txt", Delay.SLOW);
        rob.moveEndForward();
        rob.turnLeft();
        rob.moveEndForward();*/
    }


}